authorName = ''
logFolder = ''
downloadFolder = ''